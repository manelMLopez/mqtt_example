#include <Arduino.h>
#include <ESP8266WiFi.h>
#include <PubSubClient.h>

// put function declarations here:
int myFunction(int, int);

const char* ssid ="WiFi_Network";
const char* password = "1234";
const char* mqtt_server = "192.168.1.254";

WiFiClient espClient;
PubSubClient client(espClient);

// Function to connect to the wifi
void setup_wifi(){
  delay(10);
  Serial.println();
  Serial.print("Connecting to ");
  Serial.print(ssid);

  WiFi.begin(ssid, password);

  while(WiFi.status() != WL_CONNECTED){
    delay(500);
    Serial.print(".");
  }

  Serial.println("");
  Serial.println("WiFi connected");
  Serial.println("IP address: ");
  Serial.println(WiFi.localIP());
}

// Function to handle reconnecting to the MQTT broker
void reconnect() {
  // Loop until we're reconnected
  while (!client.connected()) {
    Serial.print("Attempting MQTT connection...");
    // Attempt to connect
    if (client.connect("ESP8266Client")) {
      Serial.println("connected");
      // Once connected, publish an announcement...
      client.publish("outTopic", "hello world");
    } else {
      Serial.print("failed, rc=");
      Serial.print(client.state());
      Serial.println(" try again in 5 seconds");
      // Wait 5 seconds before retrying
      delay(5000);
    }
  }
}



void setup() {
  // put your setup code here, to run once:
  int result = myFunction(2, 3);
  Serial.begin(115200);
  pinMode(LED_BUILTIN, OUTPUT);
  setup_wifi();
  client.setServer(mqtt_server, 1883);
}

void loop() {
  // put your main code here, to run repeatedly:
  digitalWrite(LED_BUILTIN, LOW);
  delay(1000);
  digitalWrite(LED_BUILTIN, HIGH);
  delay(1000);
  if (!client.connected()) {
    reconnect();
  }
  client.loop();

  // Publish a message to the MQTT topic
  client.publish("outTopic", "hello world");

  delay(5000); // Wait 5 seconds before sending the next message
}

// put function definitions here:
int myFunction(int x, int y) {
  return x + y;
}